import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { calculateNutritionGoals } from "./nutrition";
import { getProgressMotivationStatus } from "../shared/progress";
import { buildNutritionComparison } from "../shared/nutrition-chart";
import { filterHistoryMeals, sortHistoryMeals } from "../shared/history-filters";
import { plateSizeFactor, scaleByPlateSize } from "../shared/plate-size";
import { normalizeBarcode, scaleBarcodeNutrition } from "../shared/barcode-nutrition";
import { buildNutritionInsights } from "../shared/nutrition-insights";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(): TrpcContext {
  const now = new Date();
  const user: AuthenticatedUser = {
    id: 42,
    openId: "nutrition-test-user",
    email: "nutrition@example.com",
    name: "Nutrition Test",
    loginMethod: "test",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("nutrition input validation", () => {
  it("calculates maintenance calories and balanced macros from body data", () => {
    const result = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "moderate", goal: "maintain" });
    expect(result.bmr).toBe(1535);
    expect(result.calorieGoal).toBe(2380);
    expect(result.proteinGoal).toBe(149);
    expect(result.carbsGoal).toBe(268);
    expect(result.fatGoal).toBe(79);
  });

  it("uses a higher calorie target for higher activity", () => {
    const sedentary = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "sedentary", goal: "maintain" });
    const active = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "high", goal: "maintain" });
    expect(active.calorieGoal).toBeGreaterThan(sedentary.calorieGoal);
    expect(active.activityMultiplier).toBe(1.725);
  });

  it("adjusts calories and macros according to the selected goal", () => {
    const lose = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "moderate", goal: "lose" });
    const maintain = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "moderate", goal: "maintain" });
    const gain = calculateNutritionGoals({ age: 30, heightCm: 170, weightKg: 70, activityLevel: "moderate", goal: "gain" });
    expect(lose.calorieGoal).toBeLessThan(maintain.calorieGoal);
    expect(gain.calorieGoal).toBeGreaterThan(maintain.calorieGoal);
    expect(lose.proteinGoal).toBeGreaterThan(maintain.proteinGoal);
    expect(gain.carbsGoal).toBeGreaterThan(maintain.carbsGoal);
  });

  it("requires a meal description or image", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.analyzeMeal({})).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("keeps the photo note short and rejects oversized notes", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.analyzeMeal({
      description: "x".repeat(501),
      imageData: "data:image/png;base64,a",
      imageMimeType: "image/png",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects unrealistic calorie goals before touching the database", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.saveProfile({
      calorieGoal: 200,
      proteinGoal: 98,
      carbsGoal: 293,
      fatGoal: 64,
      activityLevel: "moderate",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects malformed target dates before touching the database", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.saveProfile({
      calorieGoal: 2139,
      proteinGoal: 98,
      carbsGoal: 293,
      fatGoal: 64,
      activityLevel: "moderate",
      goal: "lose",
      targetWeightKg: 65,
      targetDate: "25/09/2026",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("selects motivation based on progress and timeline", () => {
    expect(getProgressMotivationStatus(100, 20)).toBe("reached");
    expect(getProgressMotivationStatus(40, 30)).toBe("onTrack");
    expect(getProgressMotivationStatus(85, 30)).toBe("ahead");
    expect(getProgressMotivationStatus(45, 5)).toBe("deadline");
    expect(getProgressMotivationStatus(70, -1)).toBe("overdue");
    expect(getProgressMotivationStatus(10, 60)).toBe("start");
  });

  it("does not request an AI calorie change when the timeline is healthy", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.suggestCalorieAdjustment({
      currentCalories: 2200,
      progressPercent: 65,
      daysRemaining: 30,
      goal: "lose",
      adjustmentDirection: "lower",
      currentWeightKg: 78,
      targetWeightKg: 70,
      language: "ar",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("builds daily calorie totals and carries the latest actual weight forward", () => {
    const now = new Date(2026, 8, 25, 12);
    const result = buildNutritionComparison(
      [{ calories: 600, createdAt: new Date(2026, 8, 24, 10) }, { calories: 450, createdAt: new Date(2026, 8, 24, 18) }],
      [{ weightKg: 80, loggedAt: new Date(2026, 8, 24, 8) }],
      3,
      now,
    );
    expect(result).toHaveLength(3);
    expect(result[1]).toMatchObject({ calories: 1050, weight: 80 });
    expect(result[2]).toMatchObject({ calories: 0, weight: 80 });
  });

  it("supports a 30-day comparison range for the interactive chart", () => {
    const result = buildNutritionComparison([], [], 30, new Date(2026, 8, 25, 12));
    expect(result).toHaveLength(30);
    expect(result[0]).toMatchObject({ calories: 0, weight: null });
  });

  it("filters history by meal type and calorie range", () => {
    const meals = [
      { mealType: "breakfast", calories: 320 },
      { mealType: "lunch", calories: 560 },
      { mealType: "dinner", calories: 820 },
    ];
    expect(filterHistoryMeals(meals, "all", "under400")).toHaveLength(1);
    expect(filterHistoryMeals(meals, "lunch", "all")).toEqual([{ mealType: "lunch", calories: 560 }]);
    expect(filterHistoryMeals(meals, "all", "over700")).toEqual([{ mealType: "dinner", calories: 820 }]);
  });

  it("sorts history by newest or highest calorie total without mutating the source", () => {
    const meals = [
      { mealType: "lunch", calories: 560, createdAt: new Date("2026-09-24T12:00:00Z") },
      { mealType: "breakfast", calories: 820, createdAt: new Date("2026-09-25T08:00:00Z") },
    ];
    expect(sortHistoryMeals(meals, "latest").map((meal) => meal.mealType)).toEqual(["breakfast", "lunch"]);
    expect(sortHistoryMeals(meals, "caloriesDesc").map((meal) => meal.calories)).toEqual([820, 560]);
    expect(meals[0]?.mealType).toBe("lunch");
  });

  it("validates history preference values before touching the database", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.saveHistoryPreferences({
      historyMealTypeFilter: "brunch" as "all",
      historyCalorieFilter: "all",
      historySortOrder: "latest",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects an invalid frequent meal snapshot before database insertion", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.createFrequentMeal({
      name: "وجبة تجريبية",
      itemsSnapshot: JSON.stringify([{ name: "رز", grams: -10 }]),
      mealType: "lunch",
      calories: 500,
      protein: 25,
      carbs: 60,
      fat: 15,
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("requires a positive owned frequent meal id when logging", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.logFrequentMeal({ id: 0, mealType: "dinner" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("normalizes barcode input and scales nutrition by serving grams", () => {
    expect(normalizeBarcode(" 3017-6240-10701 ")).toBe("3017624010701");
    expect(normalizeBarcode("abc-123")).toBeNull();
    expect(scaleBarcodeNutrition({ calories: 500, protein: 10, carbs: 50, fat: 20, fiber: 5, sugar: 25, sodium: 300 }, 50)).toEqual({ calories: 250, protein: 5, carbs: 25, fat: 10, fiber: 2.5, sugar: 12.5, sodium: 150 });
  });

  it("returns a safe invalid result for malformed barcode lookups", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.lookupBarcode({ barcode: "abcdefgh" })).resolves.toMatchObject({ kind: "invalid" });
  });

  it("rejects barcode meal writes with an invalid barcode", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.nutrition.saveBarcodeMeal({ name: "منتج تجريبي", barcode: "123", mealType: "snack", servingGrams: 30, calories: 100, protein: 2, carbs: 10, fat: 3, fiber: 1, sugar: 4, sodium: 20 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("flags high-risk nutrition signals and produces practical alternatives", () => {
    const insights = buildNutritionInsights({ mealName: "مكبوس رز مقلي", calories: 820, fat: 36, sugar: 28, sodium: 920 });
    expect(insights.alerts).toEqual(["highSugar", "highFat", "highSodium", "highCalories"]);
    expect(insights.alternatives).toEqual(["reduceOil", "swapFried", "swapRice", "reduceSugar", "smallerPortion"]);
  });

  it("keeps insight cards quiet for a balanced meal", () => {
    expect(buildNutritionInsights({ mealName: "دجاج مشوي وخضار", calories: 420, fat: 12, sugar: 6, sodium: 400 })).toEqual({ alerts: [], alternatives: [] });
  });

  it("scales nutrition up and down relative to the original plate", () => {
    expect(scaleByPlateSize(400, "medium", "small")).toBe(300);
    expect(scaleByPlateSize(400, "medium", "large")).toBe(500);
    expect(scaleByPlateSize(400, "small", "large")).toBe(667);
  });

  it("keeps the medium plate as the neutral baseline", () => {
    expect(plateSizeFactor("medium")).toBe(1);
    expect(scaleByPlateSize(125, "medium", "medium")).toBe(125);
  });
});
